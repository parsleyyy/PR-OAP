﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ppr15
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Выполнили студенты 2 курса группы ИСП.20А");
            Console.WriteLine("Абуталыблы Ильяс и Ульянов Андрей");
            Console.WriteLine("Практическая работа №15-16");
            Console.WriteLine(@"
╔═══╗╔╗───╔═══╗╔═══╗╔═══╗╔═══╗╔═══╗
║╔═╗║║║───║╔═╗║║╔═╗║║╔═╗║║╔══╝║╔═╗║
║║─╚╝║║───║║─║║║╚══╗║╚══╗║╚══╗║╚══╗
║║─╔╗║║─╔╗║╚═╝║╚══╗║╚══╗║║╔══╝╚══╗║
║╚═╝║║╚═╝║║╔═╗║║╚═╝║║╚═╝║║╚══╗║╚═╝║
╚═══╝╚═══╝╚╝─╚╝╚═══╝╚═══╝╚═══╝╚═══╝");
            Console.WriteLine("Введите количество студентов:");
            int countstudent = int.Parse(Console.ReadLine());
            int count = System.IO.File.ReadAllLines(@"Input.txt").Length;
            List<Student> student = new List<Student>();
            StreamReader sr = new StreamReader(@"Input.txt");
            int otc = 0;
            if (countstudent < count)
            {
                for (int i = 0; i < countstudent; i++)
                {
                    string input = sr.ReadLine();
                    string[] info = input.Split(';');
                    string FIO = info[0];
                    int number = int.Parse(info[1]);
                    int math = int.Parse(info[2]);
                    int english = int.Parse(info[3]);
                    int OAP = int.Parse(info[4]);
                    int BD = int.Parse(info[5]);
                    int PE = int.Parse(info[6]);
                    student.Add(new Student(FIO, number, math, english, OAP, BD, PE));
                }
                for (int i = 0; i < countstudent; i++)
                {
                    int averag = student[i].Average();
                    if (Convert.ToDouble(averag) < 4.5)
                    {
                        Console.WriteLine(student[i].Output());
                        Console.WriteLine($"средний балл:{averag}");
                        student[i].Save();
                        otc++;
                    }
                }
                if (otc == 0)
                {
                    Console.WriteLine("Студентов с средним баллом ниже 4.5 нет");
                }
            }
            else { Console.WriteLine("Введено неверное количество студентов"); }
            sr.Close();
            Console.WriteLine("Нажмите любую клавишу для выхода");
            Console.ReadKey();

        }

    }
}
