﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ppr15
{
    class Student
    {
        private string FIO;
        private int number;
        private int math;
        private int english;
        private int OAP;
        private int BD;
        private int PE;
        public Student()
        {
            FIO = "Ivaniv I.I";
            number = 4;
            math = 4;
            english = 5;
            OAP = 3;
            BD = 5;
            PE = 5;
        }
        public Student(string f, int num, int m, int eng, int oap, int bd, int pe)
        {
            FIO = f;
            number = num;
            math = m;
            english = eng;
            OAP = oap;
            BD = bd;
            PE = pe;
        }
        public void InputFromFile(StreamReader sr)
        {
                string input = sr.ReadLine();
                string[] info = input.Split(';');
                FIO = info[0];
                number = int.Parse(info[1]);
                math = int.Parse(info[2]);
                english = int.Parse(info[3]);
                OAP = int.Parse(info[4]);
                BD = int.Parse(info[5]);
                PE = int.Parse(info[6]);

        }
        public string Output()
        {
            return $"Студент {FIO}; " +
                $"группа номер {number}; " +
                $"Оценка по математике {math}; " +
                $"Оценка по английскому {english}; " +
                $"Оценка по ОАП {OAP}; " +
                $"Оценка по базам данных {BD}; " +
                $"Оценка по физкультуре {PE}; ";
        }
        public void Save()
        {
            StreamWriter sr = new StreamWriter(@"Result.txt", true);
            sr.WriteLine($"{FIO};{number};{math};{english};{OAP};{BD};{PE}");
            sr.Close();
        }
        public int Average()
        {
            return (math + english + OAP + BD + PE) / 5;
        }
    }
}